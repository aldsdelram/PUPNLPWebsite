<?php session_start()?>

hello <?php echo $_SESSION['username']?>