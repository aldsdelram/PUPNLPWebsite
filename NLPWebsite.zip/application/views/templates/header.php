<!doctype html>

<html>
        <head>
             <title>NLPTOOLS</title>
             <link rel="stylesheet" href="/public/stylesheets/bootstrap.css">

             <style>
             	.head{
             		margin-top: 0;
             		padding-top: 0;
             		margin-bottom: 0;
             		padding-bottom: 0;
             	}

             </style>
        </head>

<body>
        <header>



        	 <nav class="navbar" style="background: maroon; color: white; margin-bottom: 0;">

		      <div class="col-md-2 col-sm-3" id="logo">
		        <div class="navbar-brand">
		          <h1 class="head">{Title}</h1>&nbsp;
		        </div>
		      </div>

		      </nav>
        </header>