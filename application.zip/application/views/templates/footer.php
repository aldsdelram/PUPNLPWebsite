 	
 	<footer class="row">
	 	<div class="container-fluid">
	 		<div class="col-xs-12 col-md-2 col-md-offset-1">
                <h4><strong>NLP TOOLS</strong></h4>
	            <p>Polytechnic Unviersity of the Philippines (Mabini Campus)<br>Anonas St., Sta. Mesa, Manila</p>
	            <ul class="list-unstyled">
	                <li><i class="fa fa-phone fa-fw"></i> (123) 456-7890</li>
	                <li><i class="fa fa-envelope-o fa-fw"></i>  <a href="mailto:pup.ccis.nlp@gmail.com">pup.ccis.nlp@gmail.com</a>
	                </li>
	            </ul>
	 		</div>

	 		<div class="col-xs-12 col-md-2 col-md-offset-1">
	 			<h4>Links </h4>
	 			<ul>
	 				<li><a href="#">HOME</a></li>
	 				<li><a href="#">ABOUT</a></li>
	 				<li><a href="#">RESEARCHES</a></li>
	 				<li><a href="#">CONTACT</a></li>
	 			</ul>	
	 		</div>

	 		<div class="col-xs-12 col-md-2 col-md-offset-1">
				Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			</div>

	 		<div class="col-xs-12 col-md-2 col-md-offset-1">			
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum
			</div>
	 	</div>
 	</footer>

 	<script>
		$('.nav a').on('click', function(){
		    if ($(document).width() <= 767){ 
		 	$(".navbar-toggle").click();
		    }
		});
	</script>
    </body>
</html>