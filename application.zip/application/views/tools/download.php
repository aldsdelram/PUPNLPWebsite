<?php
	if ($page == "request")
	echo '<h1> DOWNLOAD REQUEST SENT!</h1>'."\n";
	else
	echo'<h1> DOWNLOAD SUCCESSFULLY!</h1>'."\n";
	echo "<a href='".base_url('tools').">GO BACK TO TOOLS</a>";
?>